function test(x) {
    let a = x*2;
    let b = a + Math.sqrt(x);
    alert(a / b);
}