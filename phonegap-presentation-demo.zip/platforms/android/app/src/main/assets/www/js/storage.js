$(document).on('ready', function () {
    localStorage.setItem('username', 'admin');
    sessionStorage.setItem('session', 'sessiontext');
})
